"""
services/hindsight.py — Hindsight AI wrapper for the AI Car Mechanic.

Connects to Hindsight AI (by Vectorize) via its HTTP API.
Features:
  - System prompt enforcing expert car mechanic persona and strict automotive focus.
  - Structured output schema matching {status, question, diagnosis, symptoms, recommendation, message}.
  - Conversation retention into Hindsight memory bank 'car-mechanic'.
  - Defensive error handling: never raises unhandled exceptions.
"""

import json
import logging
import os
from typing import Any
from dotenv import load_dotenv
import httpx

logger = logging.getLogger(__name__)

HINDSIGHT_API_BASE = os.getenv("HINDSIGHT_API_BASE", "https://api.hindsight.vectorize.io")
BANK_ID = os.getenv("HINDSIGHT_BANK_ID", "car-mechanic")

SYSTEM_PROMPT = """You are an expert senior automobile technician with 25+ years of hands-on experience diagnosing and repairing all types of vehicles.

YOUR PERSONA:
- Calm, professional, methodical — like a trusted mechanic at a quality garage
- Use clear plain language; avoid unnecessary jargon
- Be empathetic: car problems cause stress and expense

YOUR RULES — follow these strictly:
1. ONLY discuss car/vehicle-related topics (diagnosis, repair, maintenance, parts, safety, driving issues). For anything unrelated, respond with status "off_topic".
2. If you do not have enough information to make a confident diagnosis, respond with status "need_more_info" and ask ONE specific, focused follow-up question in the "question" field.
3. Once you have gathered sufficient information (symptoms, context, observations), respond with status "diagnosis_ready" and provide:
   - "diagnosis": clear diagnosis — what is wrong and why
   - "symptoms": summary of the symptoms that led to this conclusion
   - "recommendation": specific, actionable next steps the customer should take
4. Never make up information. If you genuinely cannot diagnose remotely, say so honestly and recommend a professional in-person inspection.
"""

_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "status": {
            "type": "string",
            "enum": ["need_more_info", "diagnosis_ready", "off_topic"],
        },
        "question": {"type": "string"},
        "diagnosis": {"type": "string"},
        "symptoms": {"type": "string"},
        "recommendation": {"type": "string"},
        "message": {"type": "string"},
    },
    "required": ["status"],
}


def _get_api_key() -> str:
    load_dotenv(override=True)
    return os.getenv("HINDSIGHT_API_KEY", "").strip()


def call_hindsight(
    messages: list[dict[str, str]],
    image_bytes: bytes | None = None,
    image_mime: str = "image/jpeg",
) -> dict[str, Any]:
    """
    Send conversation history to Hindsight AI and return structured diagnosis/questions.
    """
    api_key = _get_api_key()
    if not api_key:
        return {
            "status": "error",
            "error": "ai_unavailable: HINDSIGHT_API_KEY is not configured.",
        }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # Format conversation history
    conv_history_lines = []
    for i, msg in enumerate(messages):
        role_label = "Mechanic" if msg.get("role") in ("model", "assistant") else "Customer"
        text = msg.get("text", "")
        if i == len(messages) - 1 and image_bytes:
            text += f" [Customer attached an image: format {image_mime}]"
        conv_history_lines.append(f"{role_label}: {text}")
    conv_text = "\n".join(conv_history_lines)

    query = f"""{SYSTEM_PROMPT}

CONVERSATION:
{conv_text}

Respond in structured JSON format according to the schema."""

    payload = {
        "query": query,
        "budget": "low",
        "response_schema": _RESPONSE_SCHEMA,
    }

    url = f"{HINDSIGHT_API_BASE}/v1/default/banks/{BANK_ID}/reflect"

    try:
        with httpx.Client(timeout=45.0) as client:
            # Retain latest customer turn into memory bank in background
            if messages:
                last_msg = messages[-1]
                if last_msg.get("role") not in ("model", "assistant"):
                    try:
                        client.post(
                            f"{HINDSIGHT_API_BASE}/v1/default/banks/{BANK_ID}/memories",
                            headers=headers,
                            json={
                                "async": True,
                                "items": [{"content": f"Customer symptom: {last_msg.get('text', '')}"}],
                            },
                            timeout=5.0,
                        )
                    except Exception:
                        pass  # Non-fatal if memory retention fails

            resp = client.post(url, headers=headers, json=payload)
            if resp.status_code != 200:
                logger.error("Hindsight API returned HTTP %s: %s", resp.status_code, resp.text)
                return {
                    "status": "error",
                    "error": f"ai_unavailable: Hindsight API error (HTTP {resp.status_code})",
                }

            data = resp.json()
            structured = data.get("structured_output")
            if not structured or not isinstance(structured, dict):
                # Fallback to parsing text field if structured_output wasn't populated
                raw_text = data.get("text", "")
                try:
                    structured = json.loads(raw_text)
                except Exception:
                    structured = {}

            status_val = structured.get("status")
            if status_val == "need_more_info":
                question = structured.get("question", "").strip()
                if not question:
                    question = "Could you please tell me more about when this issue happens?"
                return {"status": "need_more_info", "question": question}

            if status_val == "diagnosis_ready":
                return {
                    "status": "diagnosis_ready",
                    "diagnosis": structured.get("diagnosis", "").strip(),
                    "symptoms": structured.get("symptoms", "").strip(),
                    "recommendation": structured.get("recommendation", "").strip(),
                }

            if status_val == "off_topic":
                return {
                    "status": "off_topic",
                    "message": structured.get("message", "I can only assist with automotive and vehicle-related questions."),
                }

            # If status is unknown or missing
            return {
                "status": "need_more_info",
                "question": structured.get("question") or "Could you describe the car symptoms in more detail?",
            }

    except Exception as exc:
        logger.exception("Hindsight API call failed: %s", exc)
        return {
            "status": "error",
            "error": f"ai_unavailable: {type(exc).__name__}",
        }
