# AI Car Mechanic - PowerShell launcher
$root = $PSScriptRoot

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "      Launching AI Car Mechanic (Backend & Frontend)" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

Write-Host "`nStarting Backend server in a new window..." -ForegroundColor Green
Start-Process cmd.exe -ArgumentList "/k `"$root\run_backend.bat`""

Write-Host "Starting Frontend server in a new window..." -ForegroundColor Green
Start-Process cmd.exe -ArgumentList "/k `"$root\run_frontend.bat`""

Write-Host "`n========================================================" -ForegroundColor Yellow
Write-Host "Backend API:  http://localhost:8000" -ForegroundColor White
Write-Host "Frontend App: http://localhost:3000" -ForegroundColor White
Write-Host "========================================================" -ForegroundColor Yellow
Write-Host "Both servers are launching in separate windows." -ForegroundColor Gray

