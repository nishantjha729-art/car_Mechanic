@echo off
title AI Car Mechanic - Backend Server
cd /d "%~dp0backend"

if exist "%LOCALAPPDATA%\Programs\Python\Python311" (
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts;%PATH%"
)

if not exist "venv\Scripts\python.exe" (
    echo [ERROR] Virtual environment not found in backend\venv!
    pause
    exit /b 1
)

echo Starting Django Backend at http://localhost:8000 ...
venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
pause
