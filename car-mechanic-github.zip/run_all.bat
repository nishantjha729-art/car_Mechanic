@echo off
title AI Car Mechanic Launcher
echo ========================================================
echo       Launching AI Car Mechanic (Backend ^& Frontend)
echo ========================================================
echo.
echo Starting Backend in separate window...
start "AI Car Mechanic - Backend" "%~dp0run_backend.bat"
echo Starting Frontend in separate window...
start "AI Car Mechanic - Frontend" "%~dp0run_frontend.bat"
echo.
echo ========================================================
echo Backend will be available at:  http://localhost:8000
echo Frontend will be available at: http://localhost:3000
echo ========================================================
echo Both servers have been launched in separate windows.
echo Keep those windows open while using the application.
ping 127.0.0.1 -n 3 >nul

